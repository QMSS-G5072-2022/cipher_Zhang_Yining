# cipher_yz4286

Encrypt and decdecrypt

## Installation

```bash
$ pip install cipher_yz4286
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`cipher_yz4286` was created by Yining Zhang. It is licensed under the terms of the MIT license.

## Credits

`cipher_yz4286` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
